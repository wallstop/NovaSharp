﻿2025-12-08T06:23:22.6590597Z ##[group]Run ./scripts/ci/ensure-readme-updates.sh
2025-12-08T06:23:22.6590988Z [36;1m./scripts/ci/ensure-readme-updates.sh[0m
2025-12-08T06:23:22.6623358Z shell: /usr/bin/bash --noprofile --norc -e -o pipefail {0}
2025-12-08T06:23:22.6623663Z env:
2025-12-08T06:23:22.6623895Z   pythonLocation: /opt/hostedtoolcache/Python/3.12.12/x64
2025-12-08T06:23:22.6624296Z   PKG_CONFIG_PATH: /opt/hostedtoolcache/Python/3.12.12/x64/lib/pkgconfig
2025-12-08T06:23:22.6624691Z   Python_ROOT_DIR: /opt/hostedtoolcache/Python/3.12.12/x64
2025-12-08T06:23:22.6625030Z   Python2_ROOT_DIR: /opt/hostedtoolcache/Python/3.12.12/x64
2025-12-08T06:23:22.6625377Z   Python3_ROOT_DIR: /opt/hostedtoolcache/Python/3.12.12/x64
2025-12-08T06:23:22.6625731Z   LD_LIBRARY_PATH: /opt/hostedtoolcache/Python/3.12.12/x64/lib
2025-12-08T06:23:22.6626087Z   NOVASHARP_BASE_REF: 315147d1735a9f7bff14c2f07d78a159fd8e0d9c
2025-12-08T06:23:22.6626370Z ##[endgroup]
2025-12-08T06:23:22.9666412Z Documentation guard passed.
